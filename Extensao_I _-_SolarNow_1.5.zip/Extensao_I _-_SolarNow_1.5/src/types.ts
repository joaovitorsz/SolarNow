export interface Inversor {
  modelo: string;
  potenciaKW: number;
  qtde: number;
}

export interface Leitura {
  data: string;
  energiaKWh: number;
}

export type StatusUsina = "ativa" | "manutencao" | "inativa";

export interface Usina {
  id: string;
  nome: string;
  cliente: string;
  potenciaInstaladaKWp: number;
  dataAtivacao: string;
  localidade?: string;
  inversores: Inversor[];
  leituras: Leitura[];
  status: StatusUsina;

  // opcionais (guardam o que o usuário digitou)
  dailyUltimos14?: number[];
  monthlyUltimos12?: number[];
}
