import { getUsinas } from "../data/store";

function calculaPercentual(valores: number[]): number {
  if (!valores || valores.length === 0) return 0;
  const soma = valores.reduce((a, b) => a + b, 0);
  const media = soma / valores.length;
  return Math.round(media);
}

function criarLinha(usina: any): string {
  return `
    <div class="divUsinasProdutores">
      <table>
        <tr>
          <td class="tdUsinasProdutores"><b>${usina.nome}</b></td>
          <td class="tdUsinasProdutores">${usina.potenciaInstaladaKWp.toFixed(2)} kWp</td>
          <td class="tdUsinasProdutores">${usina.status}</td>
          <td class="tdUsinasProdutores">${calculaPercentual(usina.dailyUltimos14)}%</td>
          <td class="tdUsinasProdutores">${calculaPercentual(usina.monthlyUltimos12)}%</td>
        </tr>
      </table>
    </div>
  `;
}

document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("lista-usinas");
  if (!lista) return;

  const usinas = getUsinas();

  if (usinas.length === 0) {
    lista.innerHTML = `
      <p style="padding: 16px;">Nenhuma usina cadastrada ainda.</p>
    `;
    return;
  }

  lista.innerHTML = usinas.map(criarLinha).join("");
});
