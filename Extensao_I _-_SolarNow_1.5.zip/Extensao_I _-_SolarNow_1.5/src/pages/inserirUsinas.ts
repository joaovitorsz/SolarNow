import { addUsina } from "../data/store";
import type { Usina } from "../types";

// Helpers de leitura
const el = (id: string) => document.getElementById(id) as HTMLInputElement | null;
const getStr = (id: string): string => (el(id)?.value ?? "").trim();
const getNum = (id: string): number | null => {
  const raw = (el(id)?.value ?? "").replace(",", ".");
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
};

function collectSequencia(prefixo: "dia" | "mes", total: number): number[] {
  const arr: number[] = [];
  for (let i = 1; i <= total; i++) {
    const v = getNum(`${prefixo}-${i}`);
    arr.push(v ?? 0);
  }
  return arr;
}

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("formUsina") as HTMLFormElement | null;
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    // Campos básicos
    const nome = getStr("usina-nome");
    const cliente = getStr("cliente-nome");
    const localidade = getStr("cliente-localizacao");
    const contato = getStr("cliente-contato");
    const statusRaw = getStr("usina-status").toLowerCase();
    const qtdeMod = getNum("modulos-qtde");
    const potW = getNum("modulos-potencia-w");

    // Validações
    if (!nome) return alert("Informe o nome da usina.");
    if (!cliente) return alert("Informe o nome do cliente.");
    if (qtdeMod === null || qtdeMod < 0) return alert("Qtd. de módulos inválida.");
    if (potW === null || potW < 0) return alert("Potência do módulo (W) inválida.");

    const status: Usina["status"] =
      statusRaw === "manutencao" ? "manutencao" :
      statusRaw === "inativa" ? "inativa" : "ativa";

    const potenciaInstaladaKWp = (qtdeMod * potW) / 1000;

    // Séries
    const dailyUltimos14 = collectSequencia("dia", 14);
    const monthlyUltimos12 = collectSequencia("mes", 12);

    // Objeto Usina
    const nova: Usina = {
      id: crypto.randomUUID(),
      nome,
      cliente,
      potenciaInstaladaKWp,
      dataAtivacao: new Date().toISOString().slice(0, 10),
      localidade,
      inversores: [
        { modelo: "módulo", potenciaKW: (potW ?? 0) / 1000, qtde: qtdeMod ?? 0 },
      ],
      leituras: [],
      status,
      dailyUltimos14,
      monthlyUltimos12,
    };

    addUsina(nova);
    alert("Usina salva na sessão! Você já pode visualizar em Usinas/Geral.");
    // Se quiser redirecionar:
    // window.location.href = "Usinas.html";
  });
});
