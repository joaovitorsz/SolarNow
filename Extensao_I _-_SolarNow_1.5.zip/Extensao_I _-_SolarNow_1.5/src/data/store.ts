import type { Usina, Leitura } from "../types";

const SESSION_KEY = "solarnow:usinas";

function loadRaw(): Usina[] {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as Usina[]) : [];
  } catch {
    return [];
  }
}

function saveRaw(usinas: Usina[]): void {
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(usinas));
}

export function getUsinas(): Usina[] { return loadRaw(); }
export function addUsina(nova: Usina): void {
  const usinas = loadRaw();
  usinas.push(nova);
  saveRaw(usinas);
}
export function updateUsina(id: string, patch: Partial<Usina>): void {
  const usinas = loadRaw();
  const i = usinas.findIndex(u => u.id === id);
  if (i >= 0) { usinas[i] = { ...usinas[i], ...patch }; saveRaw(usinas); }
}
export function addLeitura(idUsina: string, leitura: Leitura): void {
  const usinas = loadRaw();
  const u = usinas.find(u => u.id === idUsina);
  if (u) { u.leituras.push(leitura); saveRaw(usinas); }
}
export function clearAll(): void { sessionStorage.removeItem(SESSION_KEY); }
